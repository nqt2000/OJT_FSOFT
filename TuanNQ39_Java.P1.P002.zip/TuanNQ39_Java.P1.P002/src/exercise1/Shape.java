package exercise1;

public abstract class Shape {
	public abstract double getPerimeter();

	public abstract double getArea();

	public abstract void printResult();
}
