package exercise3;

public class JavaExercise {

	public static void main(String[] args) {
		System.out.println("   J    a   v     v  a                                                 \n"
						  +"   J   a a   v   v  a a                                                \n"
					      +"J  J  aaaaa   V V  aaaaa                                               \n"
						  +" JJ  a     a   V  a     a");

	}

}
