package exercise1;

public class ArithmeticExercise1 {

	public static void main(String[] args) {
		//1. -5 + 8 * 6
		int a = -5 + 8 * 6;
		System.out.println(a);
		
		//2. (55+9) % 9
		int b = (55 + 9) % 9;
		System.out.println(b);
		
		//3. 20 + -3*5/8
		int c = 20 + -3 * 5 / 8;
		System.out.println(c);
		
		//4. 5+ 15/3*2 - 8%3
		int d = 5 + 15 / 3 * 2 - 8 % 3;
		System.out.println(d);
	}

}
